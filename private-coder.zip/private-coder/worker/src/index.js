// ============================================================
// PRIVATE CODER — Cloudflare Worker backend
// Handles: login, chat history (KV), Claude API proxy
// ============================================================

// EDIT HERE — system prompt that restricts the assistant to coding only
const SYSTEM_PROMPT = `You are a private coding assistant for a solo developer.
You ONLY help with programming, software architecture, debugging, code review,
and technical implementation (web, backend, scripts, devops, etc).
If the user asks about anything unrelated to coding/software/tech, politely
decline and ask them to ask a coding-related question instead.
Be direct and practical. Use code blocks with the correct language tag.
Keep explanations concise unless asked to elaborate.`;

// EDIT HERE — swap model if you want (claude-opus-4-7 = stronger/pricier,
// claude-haiku-4-5-20251001 = faster/cheaper)
const MODEL = "claude-sonnet-4-6";

function corsHeaders(origin) {
  return {
    "Access-Control-Allow-Origin": origin || "*",
    "Access-Control-Allow-Methods": "GET,POST,DELETE,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
  };
}

function json(data, status, origin) {
  return new Response(JSON.stringify(data), {
    status: status || 200,
    headers: { "Content-Type": "application/json", ...corsHeaders(origin) },
  });
}

async function hmac(data, secret) {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(data));
  return btoa(String.fromCharCode(...new Uint8Array(sig)))
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "");
}

async function createToken(secret) {
  const payload = btoa(JSON.stringify({ exp: Date.now() + 7 * 24 * 60 * 60 * 1000 }));
  const sig = await hmac(payload, secret);
  return `${payload}.${sig}`;
}

async function verifyToken(token, secret) {
  if (!token) return false;
  const [payload, sig] = token.split(".");
  if (!payload || !sig) return false;
  const expected = await hmac(payload, secret);
  if (sig !== expected) return false;
  try {
    const data = JSON.parse(atob(payload));
    return Date.now() < data.exp;
  } catch {
    return false;
  }
}

function getToken(request) {
  const auth = request.headers.get("Authorization") || "";
  return auth.startsWith("Bearer ") ? auth.slice(7) : null;
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const origin = env.ALLOWED_ORIGIN || "*";

    if (request.method === "OPTIONS") {
      return new Response(null, { headers: corsHeaders(origin) });
    }

    try {
      // --- LOGIN (no auth required) ---
      if (url.pathname === "/api/login" && request.method === "POST") {
        const { password } = await request.json();
        if (password !== env.AUTH_PASSWORD) {
          return json({ error: "Wrong password" }, 401, origin);
        }
        const token = await createToken(env.JWT_SECRET);
        return json({ token }, 200, origin);
      }

      // --- everything below requires a valid token ---
      const authed = await verifyToken(getToken(request), env.JWT_SECRET);
      if (!authed) return json({ error: "Unauthorized" }, 401, origin);

      // --- LIST CONVERSATIONS ---
      if (url.pathname === "/api/conversations" && request.method === "GET") {
        const list = JSON.parse((await env.CHAT_KV.get("conv_list")) || "[]");
        return json({ conversations: list }, 200, origin);
      }

      // --- CREATE NEW CONVERSATION ---
      if (url.pathname === "/api/conversations" && request.method === "POST") {
        const id = crypto.randomUUID();
        const list = JSON.parse((await env.CHAT_KV.get("conv_list")) || "[]");
        list.unshift({ id, title: "New chat", updatedAt: Date.now() });
        await env.CHAT_KV.put("conv_list", JSON.stringify(list));
        await env.CHAT_KV.put(`conv:${id}`, JSON.stringify([]));
        return json({ id }, 200, origin);
      }

      const convMatch = url.pathname.match(/^\/api\/conversations\/([a-f0-9-]+)$/);

      // --- GET ONE CONVERSATION'S MESSAGES ---
      if (convMatch && request.method === "GET") {
        const messages = JSON.parse((await env.CHAT_KV.get(`conv:${convMatch[1]}`)) || "[]");
        return json({ messages }, 200, origin);
      }

      // --- DELETE A CONVERSATION ---
      if (convMatch && request.method === "DELETE") {
        const id = convMatch[1];
        await env.CHAT_KV.delete(`conv:${id}`);
        const list = JSON.parse((await env.CHAT_KV.get("conv_list")) || "[]");
        await env.CHAT_KV.put("conv_list", JSON.stringify(list.filter((c) => c.id !== id)));
        return json({ ok: true }, 200, origin);
      }

      // --- SEND A MESSAGE ---
      if (url.pathname === "/api/chat" && request.method === "POST") {
        const { conversationId, message } = await request.json();
        if (!conversationId || !message) {
          return json({ error: "conversationId and message required" }, 400, origin);
        }

        const history = JSON.parse((await env.CHAT_KV.get(`conv:${conversationId}`)) || "[]");
        history.push({ role: "user", content: message });

        const apiRes = await fetch("https://api.anthropic.com/v1/messages", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-api-key": env.ANTHROPIC_API_KEY,
            "anthropic-version": "2023-06-01",
          },
          body: JSON.stringify({
            model: MODEL,
            max_tokens: 4096,
            system: SYSTEM_PROMPT,
            messages: history,
          }),
        });

        if (!apiRes.ok) {
          const errText = await apiRes.text();
          return json({ error: "Claude API error", details: errText }, 502, origin);
        }

        const data = await apiRes.json();
        const reply = (data.content || []).map((b) => b.text || "").join("\n");
        history.push({ role: "assistant", content: reply });

        await env.CHAT_KV.put(`conv:${conversationId}`, JSON.stringify(history));

        // auto-title the conversation from the first message
        const list = JSON.parse((await env.CHAT_KV.get("conv_list")) || "[]");
        const idx = list.findIndex((c) => c.id === conversationId);
        if (idx !== -1) {
          if (list[idx].title === "New chat") list[idx].title = message.slice(0, 40);
          list[idx].updatedAt = Date.now();
          list.sort((a, b) => b.updatedAt - a.updatedAt);
          await env.CHAT_KV.put("conv_list", JSON.stringify(list));
        }

        return json({ reply }, 200, origin);
      }

      return json({ error: "Not found" }, 404, origin);
    } catch (err) {
      return json({ error: "Server error", details: err.message }, 500, origin);
    }
  },
};
