// ============================================================
// EDIT HERE — paste your deployed Worker URL after `wrangler deploy`
// e.g. "https://private-coder-backend.yourname.workers.dev"
// ============================================================
const API_BASE = "PASTE_YOUR_WORKER_URL_HERE";

let currentConversationId = null;

// ---------- DOM refs ----------
const loginScreen = document.getElementById("login-screen");
const appScreen = document.getElementById("app-screen");
const loginForm = document.getElementById("login-form");
const passwordInput = document.getElementById("password-input");
const loginError = document.getElementById("login-error");
const conversationList = document.getElementById("conversation-list");
const messagesEl = document.getElementById("messages");
const chatForm = document.getElementById("chat-form");
const chatInput = document.getElementById("chat-input");
const sendBtn = document.getElementById("send-btn");
const newChatBtn = document.getElementById("new-chat-btn");
const logoutBtn = document.getElementById("logout-btn");
const sidebarToggle = document.getElementById("sidebar-toggle");
const sidebar = document.querySelector(".sidebar");

// ---------- API helper ----------
async function apiFetch(path, options = {}) {
  const token = localStorage.getItem("token");
  const headers = { "Content-Type": "application/json", ...(options.headers || {}) };
  if (token) headers["Authorization"] = `Bearer ${token}`;
  const res = await fetch(API_BASE + path, { ...options, headers });
  if (res.status === 401) {
    localStorage.removeItem("token");
    showLogin();
    throw new Error("Unauthorized");
  }
  return res.json();
}

// ---------- screen switching ----------
function showLogin() {
  loginScreen.classList.remove("hidden");
  appScreen.classList.add("hidden");
}
function showApp() {
  loginScreen.classList.add("hidden");
  appScreen.classList.remove("hidden");
}

// ---------- login ----------
loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  loginError.textContent = "";
  try {
    const res = await fetch(API_BASE + "/api/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password: passwordInput.value }),
    });
    const data = await res.json();
    if (!res.ok) {
      loginError.textContent = data.error || "Login failed";
      return;
    }
    localStorage.setItem("token", data.token);
    passwordInput.value = "";
    await init();
  } catch {
    loginError.textContent = "Could not reach server";
  }
});

logoutBtn.addEventListener("click", () => {
  localStorage.removeItem("token");
  showLogin();
});

// ---------- conversations ----------
async function loadConversations() {
  const { conversations } = await apiFetch("/api/conversations");
  conversationList.innerHTML = "";
  conversations.forEach((c) => {
    const item = document.createElement("div");
    item.className = "conv-item" + (c.id === currentConversationId ? " active" : "");
    item.innerHTML = `<span class="conv-title"></span><span class="del-btn">✕</span>`;
    item.querySelector(".conv-title").textContent = c.title;
    item.querySelector(".conv-title").addEventListener("click", () => selectConversation(c.id));
    item.querySelector(".del-btn").addEventListener("click", async (e) => {
      e.stopPropagation();
      await apiFetch(`/api/conversations/${c.id}`, { method: "DELETE" });
      if (c.id === currentConversationId) {
        currentConversationId = null;
        messagesEl.innerHTML = "";
      }
      await loadConversations();
    });
    conversationList.appendChild(item);
  });
  return conversations;
}

async function newConversation() {
  const { id } = await apiFetch("/api/conversations", { method: "POST" });
  currentConversationId = id;
  messagesEl.innerHTML = "";
  await loadConversations();
  chatInput.focus();
  closeSidebarOnMobile();
}

async function selectConversation(id) {
  currentConversationId = id;
  const { messages } = await apiFetch(`/api/conversations/${id}`);
  messagesEl.innerHTML = "";
  messages.forEach((m) => renderMessage(m.role, m.content));
  await loadConversations();
  scrollToBottom();
  closeSidebarOnMobile();
}

newChatBtn.addEventListener("click", newConversation);

// ---------- rendering ----------
function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

function renderContent(content) {
  // split on ```lang\ncode\n``` fences, escape everything else
  const parts = content.split(/```(\w*)\n([\s\S]*?)```/g);
  let html = "";
  for (let i = 0; i < parts.length; i += 3) {
    const text = parts[i] || "";
    html += escapeHtml(text).replace(/`([^`]+)`/g, "<code>$1</code>");
    if (parts[i + 2] !== undefined) {
      const lang = parts[i + 1] || "";
      const code = parts[i + 2];
      html += `<pre><button class="copy-btn" type="button">copy</button><code data-lang="${lang}">${escapeHtml(code)}</code></pre>`;
    }
  }
  return html;
}

function renderMessage(role, content) {
  const row = document.createElement("div");
  row.className = "msg-row " + role;
  const label = document.createElement("div");
  label.className = "msg-label";
  label.textContent = role === "user" ? "$ you" : "$ claude";
  const bubble = document.createElement("div");
  bubble.className = "msg-bubble";
  bubble.innerHTML = renderContent(content);
  row.appendChild(label);
  row.appendChild(bubble);
  messagesEl.appendChild(row);

  bubble.querySelectorAll(".copy-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const code = btn.nextElementSibling.textContent;
      navigator.clipboard.writeText(code);
      btn.textContent = "copied";
      setTimeout(() => (btn.textContent = "copy"), 1200);
    });
  });
}

function scrollToBottom() {
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

// ---------- sending messages ----------
chatForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const text = chatInput.value.trim();
  if (!text) return;

  if (!currentConversationId) {
    await newConversation();
  }

  renderMessage("user", text);
  chatInput.value = "";
  autoGrow();
  scrollToBottom();

  const thinkingRow = document.createElement("div");
  thinkingRow.className = "thinking";
  thinkingRow.textContent = "$ claude is thinking...";
  messagesEl.appendChild(thinkingRow);
  scrollToBottom();
  sendBtn.disabled = true;

  try {
    const data = await apiFetch("/api/chat", {
      method: "POST",
      body: JSON.stringify({ conversationId: currentConversationId, message: text }),
    });
    thinkingRow.remove();
    if (data.error) {
      renderMessage("assistant", `Error: ${data.error}`);
    } else {
      renderMessage("assistant", data.reply);
    }
    await loadConversations();
  } catch (err) {
    thinkingRow.remove();
    renderMessage("assistant", "Something went wrong. Check the Worker is deployed and reachable.");
  } finally {
    sendBtn.disabled = false;
    scrollToBottom();
  }
});

chatInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    chatForm.requestSubmit();
  }
});
chatInput.addEventListener("input", autoGrow);
function autoGrow() {
  chatInput.style.height = "auto";
  chatInput.style.height = Math.min(chatInput.scrollHeight, 140) + "px";
}

// ---------- mobile sidebar ----------
sidebarToggle.addEventListener("click", () => sidebar.classList.toggle("open"));
function closeSidebarOnMobile() {
  if (window.innerWidth <= 720) sidebar.classList.remove("open");
}

// ---------- init ----------
async function init() {
  showApp();
  try {
    const conversations = await loadConversations();
    if (conversations.length > 0) {
      await selectConversation(conversations[0].id);
    }
  } catch {
    // apiFetch already redirects to login on 401
  }
}

if (localStorage.getItem("token")) {
  init();
} else {
  showLogin();
}
